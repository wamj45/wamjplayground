# CSCI 1470 Fall 2020 Final Project

### Sources
For image evaluation PIL(Python Image Library) Module was utilized

> https://pillow.readthedocs.io/en/stable/

Calculation of relative luminance
> L = 0.2126R + 0.7152G + 0.0722B   
https://en.wikipedia.org/wiki/Relative_luminance
