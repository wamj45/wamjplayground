                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2097460
Micro SD card and adapter storage box  by Jipitech is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

<h4>Micro SD card storage box</h4>

No it is not a toaster.
This is a very simple box for storing your micro SD cards that we lose very easily. They can be accompanied by their SD adapter.
And if you are anxious, you can add an elastic to secure the set.
Is not life beautiful?

<strong>Update 22/02/2017</strong> :  for convenient for everybody, I modified the files with the thickness 1.4mm to 1.6mm to have a multiple of 0.4mm noze : <i>BoiteMicroSD_V02_001aBase.stl</i> and <i>BoiteMicroSD_V02_001aCouv2.stl</i>


<hr></hr>
<h4>Boîte de rangement pour cartes micro SD</h4>

Non ce n'est pas un grille pain.
Ce n'est qu'une petite boîte toute simple pour ranger vos cartes micro SD que l'on égare très facilement. Ces petites cartes peuvent être acompagnées de leur adaptateur SD.
Et si vous êtes du genre angoissé, il est même prévu d'y ajouter un élastique afin de sécuriser la fermeture de l'ensemble.
Elle est pas belle la vie ?

<strong>Mise à jour du 22/02/2017</strong> : il semblait que certains avaient un petit espace intérieur dans les angles dû à  une épaisseur non multiple de 0.4mm (buse classique). J'ai donc modifié les deux fichiers afin d'avoir une épaisseur de 1.6mm : <i>BoiteMicroSD_V02_001aBase.stl</i> et <i>BoiteMicroSD_V02_001aCouv2.stl</i>

# Print Settings

Printer: MicroDelta Rework
Resolution: 0.1mm

# How I Designed This

## FreeCAD


![Alt text](https://cdn.thingiverse.com/assets/95/d7/bd/cb/bd/BoiteMicroSD_011aFreeCAD_01.jpg)

![Alt text](https://cdn.thingiverse.com/assets/1b/43/59/66/16/BoiteMicroSD_011aFreeCAD_02.jpg)